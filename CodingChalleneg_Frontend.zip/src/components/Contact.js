import React from "react";
import { Card, Typography, Form, Input, Button } from "antd";
import "../styles/Contact.css"; 

const { Title } = Typography;

const Contact = () => {
  const handleFormSubmit = (values) => {
    console.log("Contact Form Data:", values);
    alert("Thank you for reaching out to us. We'll get back to you soon!");
  };

  return (
    <div className="contact-container">
      <Card className="contact-card" bordered={false}>
        <Title level={2}>Contact Us</Title>
        <Form layout="vertical" onFinish={handleFormSubmit}>
          <Form.Item
            label="Your Name"
            name="name"
            rules={[{ required: true, message: "Please enter your name." }]}
          >
            <Input placeholder="Enter your name" />
          </Form.Item>
          <Form.Item
            label="Email Address"
            name="email"
            rules={[
              { required: true, message: "Please enter your email." },
              { type: "email", message: "Please enter a valid email address." },
            ]}
          >
            <Input placeholder="Enter your email" />
          </Form.Item>
          <Form.Item
            label="Message"
            name="message"
            rules={[{ required: true, message: "Please enter your message." }]}
          >
            <Input.TextArea placeholder="Enter your message" rows={4} />
          </Form.Item>
          <Form.Item>
            <Button type="primary" htmlType="submit">
              Submit
            </Button>
          </Form.Item>
        </Form>
      </Card>
    </div>
  );
};

export default Contact;
