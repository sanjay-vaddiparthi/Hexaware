import React, { useContext } from "react";
import { Form, Input, Button, Card, message } from "antd";
import axios from "axios";
import Header from "./Header";
import DataContext from "./DataContext";
import "../styles/Profile.css"; 

const BASE_URL = "http://localhost:8084/";

const Profile = () => {
  const { userDetails } = useContext(DataContext);

  const handleChangePassword = async (values) => {
    try {
      await axios.put(
        `${BASE_URL}user/update/${userDetails.userName}/${values.password}`,
        {},
        {
          headers: { Authorization: `Bearer ${userDetails.jwt}` },
        }
      );
      message.success("Password updated successfully!");
    } catch (error) {
      message.error("Failed to update password.");
    }
  };

  return (
    <>
      <Header />
      <div className="profile-container">
        <Card
          title={`Welcome, ${userDetails.userName}`}
          bordered={false}
          className="profile-card"
        >
          <p className="profile-instructions">
            Use the form below to update your password securely.
          </p>
          <Form
            layout="vertical"
            onFinish={handleChangePassword}
            className="profile-form"
          >
            <Form.Item
              label="New Password"
              name="password"
              rules={[
                { required: true, message: "Password is required." },
                {
                  pattern:
                    /^(?=.*[A-Z])(?=.*[0-9])(?=.*[@$!%*?&])[A-Za-z0-9@$!%*?&]{8,}$/,
                  message:
                    "Password must contain at least 1 uppercase letter, 1 digit, 1 special character, and be at least 8 characters long.",
                },
              ]}
            >
              <Input.Password placeholder="Enter your new password" />
            </Form.Item>
            <Form.Item>
              <Button type="primary" htmlType="submit" block>
                Update Password
              </Button>
            </Form.Item>
          </Form>
        </Card>
      </div>
    </>
  );
};

export default Profile;
