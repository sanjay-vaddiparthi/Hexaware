import { createContext,useState} from "react";

const DataContext=createContext({});

export const DataProvider =({children})=>{
    const [userDetails,setUserDetails]=useState("");
    const [token,setToken]=useState("");

    const [loginFlag,setLoginFlag]=useState(false);
    const [signupFlag,setSignupFlag]=useState(true);

    return(
        <DataContext.Provider value={{
            userDetails,setUserDetails,token,setToken,
            loginFlag,setLoginFlag,signupFlag,setSignupFlag
        }}>
            {children}
        </DataContext.Provider>
    )
}
export default DataContext;