import React, { useState, useEffect, useContext } from "react";
import { Table, Button, Modal, Form, Input, message, Typography, Space } from "antd";
import axios from "axios";
import Header from "./Header";
import DataContext from "./DataContext";
import "../styles/Books.css";

const { Title } = Typography;

const Books = () => {
  const [books, setBooks] = useState([]);
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editingBook, setEditingBook] = useState(null);
  const [form] = Form.useForm();
  const { userDetails } = useContext(DataContext);

  const BASE_URL = "http://localhost:8084";

  useEffect(() => {
    fetchBooks();
  }, []);

  const fetchBooks = async () => {
    try {
      const response = await axios.get(`${BASE_URL}/book/getbooks`, {
        headers: { Authorization: `Bearer ${userDetails.jwt}` },
      });
      setBooks(response.data.map((book) => ({ ...book, key: book.bookId })));
    } catch (error) {
      message.error("Error fetching books.");
    }
  };

  const handleOk = async () => {
    try {
      const values = await form.validateFields();
      if (isEditing) {
        await axios.put(`${BASE_URL}/book/update/${editingBook.bookId}`, values, {
          headers: { Authorization: `Bearer ${userDetails.jwt}` },
        });
        message.success("Book updated successfully!");
      } else {
        const bookData = { ...values, year: parseInt(values.year) };
        await axios.post(`${BASE_URL}/book/add`, bookData, {
          headers: { Authorization: `Bearer ${userDetails.jwt}` },
        });
        message.success("Book added successfully!");
      }
      fetchBooks();
      handleCancel();
    } catch (error) {
      message.error("Failed to add or update book. Please try again.");
    }
  };

  const handleEdit = (book) => {
    setEditingBook(book);
    setIsEditing(true);
    form.setFieldsValue(book);
    setIsModalVisible(true);
  };

  const handleDelete = async (isbn) => {
    Modal.confirm({
      title: "Are you sure you want to delete this book?",
      okText: "Yes",
      okType: "danger",
      cancelText: "No",
      onOk: async () => {
        try {
          await axios.delete(`${BASE_URL}/book/delete/${isbn}`, {
            headers: { Authorization: `Bearer ${userDetails.jwt}` },
          });
          message.success("Book deleted successfully!");
          fetchBooks();
        } catch (error) {
          message.error("Failed to delete book.");
        }
      },
    });
  };

  const handleCancel = () => {
    setIsModalVisible(false);
    form.resetFields();
    setIsEditing(false);
  };

  const columns = [
    { title: "Title", dataIndex: "title", key: "title" },
    { title: "Author", dataIndex: "author", key: "author" },
    { title: "ISBN", dataIndex: "isbn", key: "isbn" },
    { title: "Published Year", dataIndex: "year", key: "year" },
    {
      title: "Actions",
      key: "actions",
      render: (_, record) => (
        <Space>
          <Button
            type="primary"
            className="edit-btn"
            onClick={() => handleEdit(record)}
          >
            Edit
          </Button>
          <Button
            type="danger"
            className="delete-btn"
            onClick={() => handleDelete(record.isbn)}
          >
            Delete
          </Button>
        </Space>
      ),
    },
  ];

  return (
    <>
      <Header />
      <div className="books-container">
        <div className="header-section">
          <Title level={3}>Manage Books</Title>
          <Space>
            <Input.Search
              placeholder="Search books..."
              style={{ width: "300px" }}
              allowClear
              onSearch={(value) => {
                const filteredBooks = books.filter(
                  (book) =>
                    book.title.toLowerCase().includes(value.toLowerCase()) ||
                    book.author.toLowerCase().includes(value.toLowerCase()) ||
                    book.isbn.toLowerCase().includes(value.toLowerCase())
                );
                setBooks(filteredBooks);
              }}
            />
            <Button
              type="primary"
              className="add-btn"
              onClick={() => setIsModalVisible(true)}
            >
              Add Book
            </Button>
          </Space>
        </div>
        <Table
          className="books-table"
          dataSource={books}
          columns={columns}
          pagination={{ pageSize: 5 }}
        />
        <Modal
          title={isEditing ? "Edit Book" : "Add Book"}
          open={isModalVisible}
          onOk={handleOk}
          onCancel={handleCancel}
          okText={isEditing ? "Update" : "Add"}
          cancelText="Cancel"
        >
          <Form layout="vertical" form={form}>
            <Form.Item
              label="Title"
              name="title"
              rules={[{ required: true, message: "Please enter the title." }]}
            >
              <Input placeholder="Enter title" />
            </Form.Item>
            <Form.Item
              label="Author"
              name="author"
              rules={[{ required: true, message: "Please enter the author." }]}
            >
              <Input placeholder="Enter author" />
            </Form.Item>
            <Form.Item
              label="ISBN"
              name="isbn"
              rules={[
                { required: true, message: "Please enter the ISBN" },
                { pattern: /^[0-9]{13}$/, message: "ISBN should be 13 digits" },
              ]}
            >
              <Input placeholder="Enter ISBN" />
            </Form.Item>
            <Form.Item
              label="Published Year"
              name="year"
              rules={[{ required: true, message: "Please enter the published year" }]}
            >
              <Input placeholder="Enter published year" />
            </Form.Item>
          </Form>
        </Modal>
      </div>
    </>
  );
};

export default Books;
