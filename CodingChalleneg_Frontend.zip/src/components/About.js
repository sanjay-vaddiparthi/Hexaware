import React from "react";
import { Card, Typography } from "antd";
import "../styles/About.css"; 

const { Title, Paragraph } = Typography;

const About = () => {
  return (
    <div className="about-container">
      <Card className="about-card" bordered={false}>
        <Title level={2}>About Us</Title>
        <Paragraph>
          We are one of the largest E-Book site provider
        </Paragraph>
        <Paragraph>
          Thank you for choosing us. We look forward to working with you!
        </Paragraph>
      </Card>
    </div>
  );
};

export default About;
