package com.hexaware.exception;

public class BookAlreadyExistsException extends Exception{

	public BookAlreadyExistsException(String msg) {
		super(msg);
	}

}
