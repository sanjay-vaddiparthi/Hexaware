package com.hexaware.exceptions;

public class PaymentNotFoundException extends Exception {
	public PaymentNotFoundException(String msg){
		super(msg);
	}

}