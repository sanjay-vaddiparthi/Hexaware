package com.hexaware.exceptions;

public class RouteNotFoundException extends Exception {

	public RouteNotFoundException(String msg) {
		super(msg);
	}
	
}
