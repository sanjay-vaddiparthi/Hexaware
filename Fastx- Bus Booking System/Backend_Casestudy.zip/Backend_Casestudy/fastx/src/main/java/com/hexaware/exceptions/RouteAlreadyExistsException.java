package com.hexaware.exceptions;

public class RouteAlreadyExistsException extends Exception {

	public RouteAlreadyExistsException(String msg) {
		super(msg);
	}
}
