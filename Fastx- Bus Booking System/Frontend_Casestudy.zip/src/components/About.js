import React from 'react';
import { Typography } from 'antd';

const { Title, Paragraph } = Typography;

function About() {
  return (
    <div style={{ padding: '24px' }}>
      <Title level={2}>About FastX</Title>
      <Paragraph>
        FastX is your ultimate online bus ticket booking solution, providing seamless
        travel experiences across the country.
      </Paragraph>
    </div>
  );
}

export default About;

