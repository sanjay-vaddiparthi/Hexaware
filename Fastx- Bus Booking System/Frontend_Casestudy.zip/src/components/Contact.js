import React from 'react';
import { Typography } from 'antd';

const { Title, Paragraph } = Typography;

function Contact() {
  return (
    <div style={{ padding: '24px' }}>
      <Title level={2}>Contact Us</Title>
      <Paragraph>
        Get in touch with us for any queries or support.
      </Paragraph>
    </div>
  );
}

export default Contact;

